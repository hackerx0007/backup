<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');
$joined = date('l, d-m-Y');
$sender = 'From: IRI BILANG BOS <reply@garena.com>';
?>