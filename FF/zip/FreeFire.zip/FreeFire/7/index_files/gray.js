var graylink = window.location.href;
var time = new Date().getTime();
if((graylink.indexOf('/HK/') > -1 || graylink.indexOf('/TW/') > -1 || graylink.indexOf('/hk/') > -1 
    || graylink.indexOf('/tw/') > -1 || graylink.indexOf('/MO/') > -1 || graylink.indexOf('/mo/') > -1 ) && time < 1586016000000) {
    document.getElementsByTagName('html')[0].style.WebkitFilter = 'grayscale(100%)';
    document.getElementsByTagName('html')[0].style.filter = 'grayscale(100%)';
}