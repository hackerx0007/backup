<?php
// KONTROL UNTUK HALAMAN
$title = 'FreeFire';
$description = 'Latest FreeFire Event. Get an exclusive prize !!!';
$copyright = 'FreeFire';
$theme = '#000';
$image = 'img/banner.png';
$icon = 'img/iconfreefire.jpg';
?>