var buka = new Audio();
buka.src = "https://5.top4top.net/m_13444g1we0.mp3";

var tutup = new Audio();
tutup.src = "https://2.top4top.net/m_1344hm49c1.mp3";